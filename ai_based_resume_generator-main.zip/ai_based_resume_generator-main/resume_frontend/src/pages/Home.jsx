import React from "react";
import LandingPage from "./LandingPage";

function Home() {
  return <LandingPage />;
}

export default Home;
